# NordVPN-Checker
# USE FOR EDUCATIONAL PURPOSES ONLY

## About
This tool should only be used for educational purposes only. This tool is used to demonstrate penetration testing on how certain cyber-criminals can bruteforce certain websites such as NordVPN to check the validity of accounts. Please do not use this for illegal activity and only use it as a reference.

## Picture
![Picture1](https://i.ibb.co/Cv0bCnv/Screenshot-97.png)

With threading (500 threads) 

![Picture1](https://i.ibb.co/WtySJkP/Screenshot-34.png)

## Installation
### Get Python
If you dont have python installed, download python 3.7.6
and make sure you click on the 'ADD TO PATH' option during
the installation.

### pip install these in cmd
```
pip install requests
pip install colorama
```

### then run the script..
```
python main.py
```
Make sure you are in the same directory as the 
python file.


